export class CreateAnalyticsDto {}
