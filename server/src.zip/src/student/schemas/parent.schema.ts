import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument } from 'mongoose';
import { Contact, ContactSchema } from './contact.schema';

export type ParentDocumentOverride = {
  contact: Contact;
};
export type ParentDocument = HydratedDocument<Parent, ParentDocumentOverride>;

@Schema({
  _id: false,
})
export class Parent {
  @Prop({ required: true })
  full_name: string;

  @Prop({ type: String, default: null })
  photo: string | null;

  @Prop({
    type: String,
    required: true,
    enum: {
      values: [
        'teacher',
        'engineer',
        'doctor',
        'business',
        'agriculture',
        'other',
      ],
      message:
        'Occupation must be one of: Teacher, Engineer, Doctor, Business, Agriculture, Other',
    },
  })
  occupation: string;

  @Prop({
    type: String,
    enum: {
      values: [
        'slc',
        'intermediate',
        'bachelor',
        'master',
        'phd',
        'illiterate',
        'other',
      ],
    },
  })
  qualification: string;

  @Prop({ type: ContactSchema })
  contact: Contact;
}

export const ParentSchema = SchemaFactory.createForClass(Parent);
