export class CreateExamDto {}
