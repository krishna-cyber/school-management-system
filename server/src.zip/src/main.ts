// THIS MUST BE THE FIRST IMPORT
import tracer from './tracer';
// Now import NestJS and other application modules
import { NestFactory } from '@nestjs/core';
import { SwaggerModule, DocumentBuilder } from '@nestjs/swagger';
import { AppModule } from './app.module';
import { ValidationPipe } from '@nestjs/common';
import { logger, OtelLoggerService } from './logger.service';

async function bootstrap() {
  // Start tracer immediately before creating the app
  tracer.start();
  const app = await NestFactory.create(AppModule, {
    bodyParser: false,
    bufferLogs: true,
  });
  app.useLogger(app.get(OtelLoggerService));

  app.useGlobalPipes(
    new ValidationPipe({ whitelist: true, disableErrorMessages: false }),
  );

  app.enableCors({
    origin: 'http://localhost:3001', // ✅ Next.js port
    credentials: true,
  });

  const config = new DocumentBuilder()
    .setTitle('School Management System API')
    .setDescription('The API documentation for the School Management System')
    .setVersion('1.0')
    .addTag('school-management')
    .build();

  const documentFactory = () => SwaggerModule.createDocument(app, config);
  SwaggerModule.setup('api', app, documentFactory);
  await app.listen(process.env.PORT ?? 3000);
  logger.log(
    `Server is running on http://localhost:${process.env.PORT ?? 3000}`,
  );
}
bootstrap();
