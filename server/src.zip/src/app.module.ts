/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
import { MiddlewareConsumer, Module, NestModule } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { SentryModule, SentryGlobalFilter } from '@sentry/nestjs/setup';
import { APP_FILTER, APP_GUARD } from '@nestjs/core';
import { MongooseModule } from '@nestjs/mongoose';
import { logger } from '@sentry/nestjs';
import { StudentModule } from './student/student.module';
import { TeacherModule } from './teacher/teacher.module';
import { AnalyticsModule } from './analytics/analytics.module';
import { ExamModule } from './exam/exam.module';
import { ClassModule } from './class/class.module';
import { FeeModule } from './fee/fee.module';
import configuration from './config/configuration';
import { seconds, ThrottlerGuard, ThrottlerModule } from '@nestjs/throttler';
import { BullModule } from '@nestjs/bullmq';
import { CacheModule } from '@nestjs/cache-manager';
import { createKeyv } from '@keyv/redis';
import { AuthModule } from '@thallesp/nestjs-better-auth';
import { auth } from './utils/auth';
import { AuthModule as AuthMo } from './auth/auth.module';
import { LoggerMiddleware } from './middlewares/logger.middleware';
import { AttendanceModule } from './attendance/attendance.module';
import { OtelLoggerService } from './logger.service';

@Module({
  imports: [
    SentryModule.forRoot(),
    AuthModule.forRoot({
      auth,
      bodyParser: {
        json: { limit: '2mb' },
        urlencoded: { limit: '2mb', extended: true },
        rawBody: true,
      },
    }),
    ConfigModule.forRoot({
      isGlobal: true,
      cache: true,
      load: [configuration],
    }),
    MongooseModule.forRootAsync({
      imports: [ConfigModule],
      useFactory: (configService: ConfigService) => ({
        uri: configService.get<string>('database.connectionString'),
        autoIndex: true,
        onConnectionCreate(connection) {
          connection.on('connected', () => {
            logger.info('MongoDB connection established successfully', {
              connectionId: connection.id,
              connectionHost: connection.host,
              connectionPort: connection.port,
            });
          });
          connection.on('disconnected', () => {
            logger.warn('MongoDB connection disconnected', {
              connectionId: connection.id,
              connectionHost: connection.host,
              connectionPort: connection.port,
            });
          });
          return connection;
        },
      }),
      inject: [ConfigService],
    }),
    ThrottlerModule.forRoot({
      throttlers: [
        { name: 'short', limit: 3, ttl: seconds(4) },
        { name: 'medium', limit: 15, ttl: seconds(30) },
        { name: 'long', limit: 25, ttl: seconds(80) },
      ],
    }),
    BullModule.forRootAsync({
      imports: [ConfigModule],
      useFactory: (configService: ConfigService) => ({
        connection: {
          host: configService.get('redis.host'),
          port: configService.get('redis.port'),
        },
        defaultJobOptions: { attempts: 3 },
      }),
      inject: [ConfigService],
    }),
    CacheModule.registerAsync({
      isGlobal: true,
      useFactory: (configService: ConfigService) => ({
        ttl: seconds(300), // default cache TTL of 5 minutes
        stores: [
          createKeyv(
            `redis://${configService.get('redis.host')}:${configService.get('redis.port')}`,
          ),
        ],
      }),
      inject: [ConfigService],
    }),
    StudentModule,
    TeacherModule,
    AnalyticsModule,
    ExamModule,
    ClassModule,
    FeeModule,
    AuthMo,
    AttendanceModule,
  ],
  controllers: [AppController],
  providers: [
    OtelLoggerService,
    AppService,
    {
      provide: APP_FILTER,
      useClass: SentryGlobalFilter,
    },
    {
      provide: APP_GUARD,
      useClass: ThrottlerGuard,
    },
  ],
  exports: [MongooseModule],
})
export class AppModule implements NestModule {
  configure(consumer: MiddlewareConsumer) {
    consumer.apply(LoggerMiddleware).forRoutes('*'); // log all routes
  }
}
